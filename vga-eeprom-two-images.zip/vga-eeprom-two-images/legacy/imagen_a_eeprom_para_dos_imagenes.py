#!/usr/bin/env python3
"""
============================================================================
 imagen_a_eeprom.py

 Convierte cualquier foto a 100 x 75 pixeles con 64 colores (formato RRGGBB)
 y la envia al Arduino que graba la AT28C256 de la tarjeta de video VGA.

 Pareja del sketch:  grabador_vga_28c256.ino

 Requisitos:   pip install pillow pyserial

----------------------------------------------------------------------------
 USO TIPICO

   1) Convertir y mirar como va a quedar ANTES de gastar 75 s de grabacion:
        python imagen_a_eeprom.py convertir foto.jpg -o imagen.bin --vista previa.png

   2) Grabar:
        python imagen_a_eeprom.py grabar imagen.bin --puerto COM3

   3) Verificar lo que quedo en el chip:
        python imagen_a_eeprom.py verificar imagen.bin --puerto COM3

   4) Todo de una:
        python imagen_a_eeprom.py convertir foto.jpg -o imagen.bin && \
        python imagen_a_eeprom.py grabar imagen.bin --puerto COM3 --verificar

 En Linux/Mac el puerto suele ser /dev/ttyUSB0 o /dev/cu.usbserial-XXXX.

----------------------------------------------------------------------------
 FORMATO DE SALIDA

 Un archivo .bin de 7500 bytes: 75 filas de 100 bytes, sin relleno.
 El relleno de 28 bytes por fila (para completar los 128 del paso de fila)
 NO se incluye porque esas columnas caen en el blanking horizontal y nunca
 se leen; el sketch se encarga de saltarlas. Tampoco se rellena el chip a
 32 KB: eso lo exige el software minipro, no el hardware.

 Cada byte:   0 0 R R G G B B    con R, G, B de 0 a 3.

 Si cableaste el DAC en otro orden (por ejemplo B en los bits altos), cambia
 la constante ORDEN mas abajo. Es el unico lugar que hay que tocar.
============================================================================
"""

import argparse
import sys
import time

ANCHO, ALTO = 100, 75
NBYTES = ANCHO * ALTO            # 7500

# Orden de los canales dentro del byte, del bit mas significativo al menos.
# "RGB" -> bits 5-4 = rojo, 3-2 = verde, 1-0 = azul.
# Cambia a "BGR" u otro si tu cableado del DAC es distinto.
ORDEN = "RGB"

_POS = {c: (4 - 2 * i) for i, c in enumerate(ORDEN)}   # canal -> desplazamiento


def empaquetar(r, g, b):
    """r, g, b de 0 a 3  ->  byte del formato elegido."""
    return (r << _POS["R"]) | (g << _POS["G"]) | (b << _POS["B"])


def desempaquetar(v):
    """byte -> (r, g, b) de 0 a 3."""
    return ((v >> _POS["R"]) & 3, (v >> _POS["G"]) & 3, (v >> _POS["B"]) & 3)


def paleta():
    """Los 64 colores, en RGB de 8 bits. 255/3 = 85 por escalon."""
    return [tuple(c * 85 for c in desempaquetar(i)) for i in range(64)]


# ---------------------------------------------------------------------------
# Conversion de la imagen
# ---------------------------------------------------------------------------

def convertir(ruta, dither=True):
    """Abre la imagen, la recorta a 4:3, la lleva a 100x75 y la cuantiza."""
    from PIL import Image

    im = Image.open(ruta).convert("RGB")
    w, h = im.size

    # Recorte centrado a 4:3 para no deformar la foto.
    if w * ALTO > h * ANCHO:
        nw = h * ANCHO // ALTO
        x0 = (w - nw) // 2
        im = im.crop((x0, 0, x0 + nw, h))
    else:
        nh = w * ALTO // ANCHO
        y0 = (h - nh) // 2
        im = im.crop((0, y0, w, y0 + nh))

    im = im.resize((ANCHO, ALTO), Image.LANCZOS)

    # Cuantizacion. La paleta es un cubo uniforme de 4 niveles por canal, asi
    # que redondear cada canal por separado YA da el color mas cercano: no
    # hace falta buscar en una tabla.
    #
    # Con dither (Floyd-Steinberg) el error de cada pixel se reparte entre los
    # vecinos todavia no procesados. Con 64 colores la diferencia en una foto
    # es grande: sin dither salen bandas planas en los degradados.
    buf = [list(p) for p in im.getdata()]
    salida = bytearray(NBYTES)

    for y in range(ALTO):
        for x in range(ANCHO):
            i = y * ANCHO + x
            viejo = buf[i]
            niv = [min(3, max(0, int(round(c / 85.0)))) for c in viejo]
            salida[i] = empaquetar(*niv)
            if dither:
                err = [viejo[k] - niv[k] * 85 for k in range(3)]
                for dx, dy, f in ((1, 0, 7 / 16), (-1, 1, 3 / 16),
                                  (0, 1, 5 / 16), (1, 1, 1 / 16)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < ANCHO and 0 <= ny < ALTO:
                        j = ny * ANCHO + nx
                        for k in range(3):
                            buf[j][k] += err[k] * f

    return bytes(salida)


def guardar_vista(datos, ruta, escala=6):
    """Guarda un PNG ampliado con los colores exactos que vera el monitor."""
    from PIL import Image
    pal = paleta()
    im = Image.new("RGB", (ANCHO, ALTO))
    im.putdata([pal[b & 0x3F] for b in datos])
    im.resize((ANCHO * escala, ALTO * escala), Image.NEAREST).save(ruta)


# ---------------------------------------------------------------------------
# Puerto serie
# ---------------------------------------------------------------------------

def abrir(puerto, baudios=57600, timeout=10):
    import serial
    s = serial.Serial(puerto, baudios, timeout=timeout)
    time.sleep(2.5)              # el Nano se reinicia al abrir el puerto
    s.reset_input_buffer()
    return s


def esperar(s, token, limite=25):
    """Lee hasta encontrar el token y consume el resto de la linea."""
    objetivo = token.encode()
    buf = b""
    t0 = time.time()
    while time.time() - t0 < limite:
        ch = s.read(1)
        if not ch:
            continue
        buf += ch
        if buf.endswith(objetivo):
            s.readline()
            return True
        if len(buf) > 4096:
            buf = buf[-64:]
    return False


def grabar(s, datos, banco=0):
    if len(datos) != NBYTES:
        sys.exit(f"El archivo tiene {len(datos)} bytes; se esperaban {NBYTES}.")
    s.reset_input_buffer()
    s.write(b"W" if banco else b"w")
    if not esperar(s, "READY"):
        sys.exit("El Arduino no respondio READY. Revisa el puerto y los baudios (57600).\n"
                 "Si grababas el banco 1: el sketch pudo detectar A14 en espejo "
                 "(pin 1 a GND?). Abre el monitor serie y usa el comando k.")

    t0 = time.time()
    for i, b in enumerate(datos):
        s.write(bytes([b]))
        a = s.read(1)
        if a != b"\x06":
            sys.exit(f"\nSin ACK en el byte {i} (llego {a!r}). "
                     f"Fila {i // ANCHO}, columna {i % ANCHO}.")
        if i % 250 == 0:
            pct = 100.0 * i / NBYTES
            print(f"\r  grabando  {pct:5.1f} %   ({i}/{NBYTES})", end="", flush=True)
    print(f"\r  grabando  100.0 %   ({NBYTES}/{NBYTES})")
    print(f"  tiempo: {time.time() - t0:.0f} s")


def leer(s, banco=0):
    s.reset_input_buffer()
    s.write(b"R" if banco else b"r")
    if not esperar(s, "DATA"):
        sys.exit("El Arduino no respondio DATA.")
    anterior, s.timeout = s.timeout, 30
    got = s.read(NBYTES)
    s.timeout = anterior
    if len(got) != NBYTES:
        sys.exit(f"Solo llegaron {len(got)} de {NBYTES} bytes.")
    return got


def comparar(esperado, leido):
    malos = [i for i in range(NBYTES) if esperado[i] != leido[i]]
    if not malos:
        print(f"  verificacion: {NBYTES} de {NBYTES} bytes correctos.")
        return 0

    print(f"  verificacion: {len(malos)} bytes distintos de {NBYTES}.")
    for i in malos[:10]:
        y, x = divmod(i, ANCHO)
        print(f"    fila {y:2d} col {x:3d} (dir 0x{(y << 7) | x:04X}): "
              f"escrito 0x{esperado[i]:02X}, leido 0x{leido[i]:02X}")

    # Diagnostico por filas: si los errores se concentran en las filas 64 a 74
    # casi seguro A13 (pin 26) no esta llegando al QF del 595.
    altas = sum(1 for i in malos if i // ANCHO >= 64)
    if altas > len(malos) * 0.9:
        print("\n  AVISO: casi todos los errores estan en las filas 64 a 74.")
        print("  Esa es la firma de A13 (pin 26) sin conectar o a GND:")
        print("  con A13 en 0 no se puede escribir arriba de la direccion 8191.")

    # Diagnostico por bits: un bit que falla siempre apunta a una linea de datos.
    mascara = 0
    for i in malos:
        mascara |= esperado[i] ^ leido[i]
    bits = [k for k in range(8) if mascara & (1 << k)]
    if len(bits) == 1:
        print(f"\n  AVISO: todos los errores estan en el bit {bits[0]} "
              f"(I/O{bits[0]}, pin {[11,12,13,15,16,17,18,19][bits[0]]} del chip).")
    return len(malos)


# ---------------------------------------------------------------------------
# Linea de comandos
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Convierte y graba imagenes en la AT28C256 de la tarjeta VGA.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("convertir", help="foto -> .bin de 7500 bytes")
    c.add_argument("imagen")
    c.add_argument("-o", "--salida", default="imagen.bin")
    c.add_argument("--vista", help="guarda un PNG ampliado de como quedara")
    c.add_argument("--sin-dither", action="store_true",
                   help="cuantiza sin Floyd-Steinberg (bandas mas marcadas)")

    g = sub.add_parser("grabar", help="envia el .bin al Arduino")
    g.add_argument("binario")
    g.add_argument("--puerto", required=True)
    g.add_argument("--banco", type=int, choices=[0, 1], default=0,
                   help="0 = imagen 1 (A14=0), 1 = imagen 2 (A14=1)")
    g.add_argument("--verificar", action="store_true",
                   help="relee el chip al terminar y compara")

    v = sub.add_parser("verificar", help="relee el chip y compara con un .bin")
    v.add_argument("binario")
    v.add_argument("--puerto", required=True)
    v.add_argument("--banco", type=int, choices=[0, 1], default=0)

    d = sub.add_parser("descargar", help="guarda lo que hay en el chip como PNG")
    d.add_argument("--puerto", required=True)
    d.add_argument("--banco", type=int, choices=[0, 1], default=0)
    d.add_argument("-o", "--salida", default="leido.png")

    a = ap.parse_args()

    if a.cmd == "convertir":
        datos = convertir(a.imagen, dither=not a.sin_dither)
        with open(a.salida, "wb") as f:
            f.write(datos)
        print(f"  {a.salida}: {len(datos)} bytes ({ANCHO}x{ALTO}, 64 colores)")
        usados = len(set(datos))
        print(f"  colores distintos usados: {usados} de 64")
        if a.vista:
            guardar_vista(datos, a.vista)
            print(f"  vista previa: {a.vista}")

    elif a.cmd == "grabar":
        datos = open(a.binario, "rb").read()
        s = abrir(a.puerto)
        try:
            grabar(s, datos, a.banco)
            if a.verificar:
                comparar(datos, leer(s, a.banco))
        finally:
            s.close()

    elif a.cmd == "verificar":
        datos = open(a.binario, "rb").read()
        s = abrir(a.puerto)
        try:
            comparar(datos, leer(s, a.banco))
        finally:
            s.close()

    elif a.cmd == "descargar":
        s = abrir(a.puerto)
        try:
            datos = leer(s, a.banco)
        finally:
            s.close()
        guardar_vista(datos, a.salida)
        print(f"  {a.salida}")


if __name__ == "__main__":
    main()
