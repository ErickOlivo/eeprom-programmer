# Legacy (Spanish) versions

These are the original files, with Spanish comments and messages, exactly as
they were used in the lab. The results in the main README were obtained with
the v2 files.

| File | Version | Description |
|---|---|---|
| `grabador_vga_28c256/grabador_vga_28c256.ino` | v1 | Single-image programmer (bank 0 only) |
| `imagen_a_eeprom.py` | v1 | Single-image converter and writer |
| `grabador_vga_28c256_v2_bancos/grabador_vga_28c256_v2_bancos.ino` | v2 | Two-bank programmer |
| `imagen_a_eeprom_para_dos_imagenes.py` | v2 | Two-bank tool (`--banco 0/1`) |

The English versions in `firmware/` and `tools/` replace them and use the same
serial protocol, so the v2 Python tool also works with the English firmware
and vice versa. The v1 tool works with v2 firmware for bank 0.
