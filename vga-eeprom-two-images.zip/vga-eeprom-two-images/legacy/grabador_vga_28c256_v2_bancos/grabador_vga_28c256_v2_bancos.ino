/*
 * ============================================================================
 *  grabador_vga_28c256_v2_bancos.ino
 *
 *  Graba DOS imagenes de 100 x 75 pixeles (64 colores, RRGGBB) en una
 *  AT28C256, una en cada mitad del chip ("banco"):
 *
 *      Banco 0  (A14 = 0)   direcciones 0x0000 - 0x257F   <- imagen 1
 *      Banco 1  (A14 = 1)   direcciones 0x4000 - 0x657F   <- imagen 2
 *
 *  direccion = (banco << 14) | (Y << 7) | X     X = 0..99    Y = 0..74
 *
 *  Pareja de:  imagen_a_eeprom_v2.py   (opcion --banco 0|1)
 *  Basado en:  grabador_vga_28c256.ino (mismo cableado, mismo protocolo)
 *
 * ----------------------------------------------------------------------------
 *  >>> REQUISITO DE HARDWARE (LEER ANTES DE GRABAR EL BANCO 1) <<<
 *
 *  En el PROGRAMADOR, A14 (pin 1 de la 28C256) tiene que ir a QG del 595 #2.
 *  Si sigue a GND, escribir "en el banco 1" ESCRIBE ENCIMA DEL BANCO 0 y
 *  pierdes la imagen 1.  El sketch lo detecta antes de grabar (comando 'k' y
 *  chequeo automatico), pero la deteccion es heuristica: verifica tu cable.
 *
 *  En la TARJETA DE VIDEO, para VER cada imagen:
 *      A14 (pin 1) -> GND   : se muestra la imagen 1
 *      A14 (pin 1) -> +5 V  : se muestra la imagen 2
 *  (lo ideal: un interruptor o jumper de 3 pines; nunca A14 flotando).
 *
 * ----------------------------------------------------------------------------
 *  CABLEADO (igual que la version anterior)
 *
 *    D2 -> SER (pin 14 de los 595)   D3 -> SRCLK (pin 11)   D4 -> RCLK (pin 12)
 *
 *    595 #1:  QA..QH -> A0..A7    (EEPROM pines 10, 9, 8, 7, 6, 5, 4, 3)
 *    595 #2:  QA -> A8  (pin 25)   QB -> A9  (pin 24)   QC -> A10 (pin 21)
 *             QD -> A11 (pin 23)   QE -> A12 (pin 2)    QF -> A13 (pin 26)
 *             QG -> A14 (pin 1)    QH -> OE  (pin 22)
 *
 *    D5..D12 -> I/O0..I/O7   (EEPROM pines 11, 12, 13, 15, 16, 17, 18, 19)
 *    D13     -> WE           (pin 27)
 *    CE (pin 20) -> GND      GND (pin 14) -> GND      VCC (pin 28) -> +5 V
 *
 * ----------------------------------------------------------------------------
 *  COMANDOS  (minuscula = banco 0, MAYUSCULA = banco 1)
 *
 *    ?       ayuda
 *    a       prueba de lineas de direccion A0..A14
 *    k       chequeo de A14: compara el banco 0 contra el banco 1
 *    d / D   volcado hexadecimal de las primeras 4 filas del banco 0 / 1
 *    t / T   patron de prueba (T lo graba con colores INVERTIDOS para que
 *            distingas a simple vista que banco estas viendo)
 *    w / W   recibe 7500 bytes por serie y los graba en el banco 0 / 1
 *    r / R   devuelve los 7500 bytes leidos del banco 0 / 1 (binario)
 *    z / Z   borra la zona de imagen del banco 0 / 1 a 0x00
 *    s       desbloqueo SDP (exige A14 en QG)
 *
 *  Por que mayuscula/minuscula y no un comando "elegir banco": al abrir el
 *  puerto serie, el Nano se reinicia (DTR) y olvidaria el banco elegido.
 *  Asi el banco viaja dentro del propio comando y el script de Python no
 *  necesita una conversacion previa.
 *
 *  Seguridad de escritura: igual que antes. Reposo con WE alto y OE bajo;
 *  bandera 'armed' solo durante los comandos que graban. Mover cables con el
 *  USB desconectado.
 * ============================================================================
 */

#define SHIFT_DATA    2
#define SHIFT_CLK     3
#define SHIFT_LATCH   4
#define EEPROM_D0     5
#define EEPROM_D7    12
#define WRITE_EN     13

#define IMG_W       100
#define IMG_H        75
#define IMG_BYTES   ((unsigned int)IMG_W * IMG_H)   // 7500
#define BANK_SIZE   0x4000u                          // 16384 bytes (A14)

const byte ACK = 0x06;

bool armed = false;    // solo true mientras corre un comando que graba

/* -------------------------------------------------------------------------
 *  Bus de datos por manipulacion directa de puertos
 *  D5,D6,D7 = PD5..PD7 -> I/O0..I/O2    D8..D12 = PB0..PB4 -> I/O3..I/O7
 *  D13 (PB5) = WE (las mascaras lo preservan)
 * ------------------------------------------------------------------------- */

static inline void dataBusInput() {
  DDRD  &= ~0xE0;
  DDRB  &= ~0x1F;
  PORTD &= ~0xE0;
  PORTB &= ~0x1F;
}

static inline void dataBusOutput() {
  DDRD |= 0xE0;
  DDRB |= 0x1F;
}

static inline void dataBusWrite(byte d) {
  PORTD = (PORTD & ~0xE0) | ((d & 0x07) << 5);
  PORTB = (PORTB & ~0x1F) | ((d >> 3) & 0x1F);
}

/* -------------------------------------------------------------------------
 *  Direccionamiento (byte alto primero: QH=OE, QG=A14, QF=A13 ... QA=A8)
 * ------------------------------------------------------------------------- */

void setAddress(unsigned int address, bool outputEnable) {
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST,
           (byte)((address >> 8) | (outputEnable ? 0x00 : 0x80)));
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, (byte)address);
  digitalWrite(SHIFT_LATCH, LOW);
  digitalWrite(SHIFT_LATCH, HIGH);
  digitalWrite(SHIFT_LATCH, LOW);
}

// Version rapida solo para la secuencia SDP (t_BLC ~150 us)
static void fastShiftByte(byte v) {
  for (byte i = 0; i < 8; i++) {
    if (v & 0x80) PORTD |= _BV(PD2); else PORTD &= ~_BV(PD2);
    PORTD |=  _BV(PD3);
    PORTD &= ~_BV(PD3);
    v <<= 1;
  }
}

static void fastSetAddress(unsigned int address, bool outputEnable) {
  fastShiftByte((byte)((address >> 8) | (outputEnable ? 0x00 : 0x80)));
  fastShiftByte((byte)address);
  PORTD |=  _BV(PD4);
  PORTD &= ~_BV(PD4);
}

// bank = 0 o 1.  A14 es el bit 14 de la direccion (0x4000).
static inline unsigned int pixelAddr(byte x, byte y, byte bank) {
  return ((unsigned int)bank << 14) | ((unsigned int)y << 7) | x;
}

/* -------------------------------------------------------------------------
 *  Lectura, escritura y reposo
 * ------------------------------------------------------------------------- */

void restState() {
  digitalWrite(WRITE_EN, HIGH);
  dataBusInput();
  setAddress(0, true);          // OE bajo: escritura inhibida por hardware
}

byte readEEPROM(unsigned int address) {
  dataBusInput();
  setAddress(address, true);
  delayMicroseconds(2);         // > t_ACC del chip
  byte data = 0;
  for (int pin = EEPROM_D7; pin >= EEPROM_D0; pin--)
    data = (data << 1) | digitalRead(pin);
  return data;
}

void writeEEPROM(unsigned int address, byte data) {
  if (!armed) return;           // sin confirmar no se escribe nada
  setAddress(address, false);   // OE alto: escritura habilitada
  dataBusOutput();
  dataBusWrite(data);
  digitalWrite(WRITE_EN, LOW);
  delayMicroseconds(1);         // pulso ~1 us (minimo del chip: 100 ns)
  digitalWrite(WRITE_EN, HIGH);
  dataBusInput();
  delay(10);                    // ciclo interno de escritura (t_WC max)
}

/* -------------------------------------------------------------------------
 *  Utilidades de consola
 * ------------------------------------------------------------------------- */

void printHex(byte b) {
  if (b < 16) Serial.print('0');
  Serial.print(b, HEX);
}

bool confirm(const __FlashStringHelper *msg) {
  Serial.println(msg);
  delay(100);
  while (Serial.available()) Serial.read();
  unsigned long t0 = millis();
  while (!Serial.available()) {
    if (millis() - t0 > 15000UL) {
      Serial.println(F("Cancelado (sin respuesta en 15 s)."));
      return false;
    }
  }
  if (Serial.read() != 'Y') {
    Serial.println(F("Cancelado."));
    return false;
  }
  return true;
}

void help() {
  Serial.println();
  Serial.println(F("Grabador VGA AT28C256 v2 - 2 bancos (100x75, 64 colores RRGGBB)"));
  Serial.println(F("  minuscula = banco 0 (A14=0)   MAYUSCULA = banco 1 (A14=1)"));
  Serial.println(F("  ?    ayuda"));
  Serial.println(F("  a    prueba de lineas A0..A14"));
  Serial.println(F("  k    chequeo de A14 (banco 0 vs banco 1)"));
  Serial.println(F("  d/D  volcado hex de 4 filas"));
  Serial.println(F("  t/T  patron de prueba (T = colores invertidos)"));
  Serial.println(F("  w/W  recibir y grabar imagen por serie (7500 bytes)"));
  Serial.println(F("  r/R  devolver los 7500 bytes leidos (binario)"));
  Serial.println(F("  z/Z  borrar zona de imagen a 0x00"));
  Serial.println(F("  s    desbloqueo SDP [exige A14 en QG]"));
}

/* -------------------------------------------------------------------------
 *  Diagnostico de A14
 *
 *  Compara 64 bytes del banco 0 con 64 del banco 1 (primera fila + parte de
 *  la segunda). Si A14 NO llega al chip (pin 1 a GND o suelto), las dos
 *  mitades son espejo: los 64 bytes salen identicos.
 *
 *  Limite del metodo: si ambos bancos tuvieran de verdad contenido igual
 *  (por ejemplo los dos vacios, todo FF), tambien dira "espejo". Por eso el
 *  chequeo es solo una alarma, no una prueba. La prueba definitiva: grabar
 *  el patron T en el banco 1 y verificar con 'd' que el banco 0 sigue igual.
 * ------------------------------------------------------------------------- */

// devuelve true si A14 parece funcionar (los bancos difieren)
bool a14Differs() {
  for (byte i = 0; i < 64; i++) {
    if (readEEPROM(i) != readEEPROM(BANK_SIZE + i)) return true;
  }
  return false;
}

void checkA14() {
  Serial.println(F("Banco 0 (0x0000):  Banco 1 (0x4000):"));
  for (byte i = 0; i < 8; i++) {
    printHex(readEEPROM(i));
    Serial.print(F(" "));
  }
  Serial.print(F("  |  "));
  for (byte i = 0; i < 8; i++) {
    printHex(readEEPROM(BANK_SIZE + i));
    Serial.print(F(" "));
  }
  Serial.println();
  if (a14Differs()) {
    Serial.println(F("OK: los bancos son distintos -> A14 llega al chip."));
  } else {
    Serial.println(F("AVISO: los bancos son IDENTICOS (espejo)."));
    Serial.println(F("  Causas: A14 (pin 1) a GND/suelto, o ambos bancos vacios (FF)."));
    Serial.println(F("  Mide el pin 1 con el multimetro: debe cambiar 0 V <-> 5 V"));
    Serial.println(F("  segun la direccion (QG del 595 #2)."));
  }
}

// Antes de grabar el banco 1: si parece espejo, advierte del riesgo.
bool bank1Safe() {
  if (a14Differs()) return true;
  return confirm(F("AVISO: banco 1 parece espejo del 0. Si A14 esta a GND, GRABAR AQUI "
                   "BORRA LA IMAGEN 1. Seguro? Envia Y."));
}

void addressLines() {
  Serial.print(F("0x0000 = "));
  printHex(readEEPROM(0));
  Serial.println();
  for (byte k = 0; k < 15; k++) {            // A0..A14
    unsigned int a = (unsigned int)1 << k;
    Serial.print(F("A"));
    Serial.print(k);
    Serial.print(F(" (0x"));
    Serial.print(a, HEX);
    Serial.print(F(") = "));
    printHex(readEEPROM(a));
    Serial.println();
  }
}

void dumpHex(byte bank) {
  Serial.print(F("Banco "));
  Serial.println(bank);
  for (byte y = 0; y < 4; y++) {
    for (byte base = 0; base < IMG_W; base += 16) {
      char buf[8];
      sprintf(buf, "%04X:", pixelAddr(base, y, bank));
      Serial.print(buf);
      for (byte off = 0; off < 16 && (byte)(base + off) < IMG_W; off++) {
        Serial.print(' ');
        printHex(readEEPROM(pixelAddr(base + off, y, bank)));
      }
      Serial.println();
    }
  }
}

/* -------------------------------------------------------------------------
 *  Patron de prueba: rejilla 8x8 con los 64 colores y borde blanco.
 *  En el banco 1 se invierten los 6 bits (c ^ 0x3F): el borde sale NEGRO y
 *  la rejilla con colores complementarios. Asi, al conmutar A14 en la tarjeta,
 *  el cambio es inconfundible.
 * ------------------------------------------------------------------------- */

void testPattern(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  if (!confirm(F("Patron de prueba: SOBRESCRIBE el banco elegido. Envia Y."))) return;
  armed = true;
  Serial.print(F("Grabando patron en banco "));
  Serial.print(bank);
  Serial.println(F(" (aprox. 75 s)..."));
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) {
      byte c;
      if (x == 0 || x == IMG_W - 1 || y == 0 || y == IMG_H - 1) {
        c = 0x3F;
      } else {
        byte col = (byte)(((unsigned int)x * 8) / IMG_W);
        byte row = (byte)(((unsigned int)y * 8) / IMG_H);
        c = (byte)(row * 8 + col);
      }
      if (bank == 1) c ^= 0x3F;
      writeEEPROM(pixelAddr(x, y, bank), c);
    }
    Serial.print('.');
  }
  armed = false;
  restState();
  Serial.println();
  Serial.println(F("Patron grabado."));
}

void eraseImage(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  if (!confirm(F("Borra la zona de imagen del banco elegido a 0x00. Envia Y."))) return;
  armed = true;
  Serial.print(F("Borrando banco "));
  Serial.print(bank);
  Serial.println(F(" (aprox. 75 s)..."));
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) writeEEPROM(pixelAddr(x, y, bank), 0x00);
    Serial.print('.');
  }
  armed = false;
  restState();
  Serial.println();
  Serial.println(F("Listo."));
}

/* -------------------------------------------------------------------------
 *  Imagen por puerto serie (mismo protocolo que la v1)
 *    PC -> 'w' (banco 0) o 'W' (banco 1)
 *    AR -> "READY\r\n"
 *    repetir 7500 veces:  PC -> 1 byte | AR graba y responde 0x06
 *    AR -> "DONE 7500\r\n"
 *
 *  Nota: el aviso de espejo del banco 1 usa confirm(), que espera 'Y' del
 *  usuario. Desde Python no hay quien responda, asi que si el chequeo dispara
 *  el script recibira "Cancelado" en vez de READY y se detendra: es lo
 *  deseado (preferible a borrar la imagen 1 por un cable mal puesto).
 * ------------------------------------------------------------------------- */

void receiveImage(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  delay(50);
  while (Serial.available()) Serial.read();
  Serial.println(F("READY"));
  armed = true;
  unsigned int count = 0;
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) {
      unsigned long t0 = millis();
      while (!Serial.available()) {
        if (millis() - t0 > 10000UL) {
          armed = false;
          restState();
          Serial.println();
          Serial.print(F("TIMEOUT en el byte "));
          Serial.println(count);
          return;
        }
      }
      writeEEPROM(pixelAddr(x, y, bank), (byte)Serial.read());
      Serial.write(ACK);
      count++;
    }
  }
  armed = false;
  restState();
  Serial.print(F("DONE "));
  Serial.println(count);
}

void dumpImageBinary(byte bank) {
  Serial.println(F("DATA"));
  delay(10);
  for (byte y = 0; y < IMG_H; y++)
    for (byte x = 0; x < IMG_W; x++)
      Serial.write(readEEPROM(pixelAddr(x, y, bank)));
  Serial.flush();
}

/* -------------------------------------------------------------------------
 *  Desbloqueo del Software Data Protection (sin cambios; exige A14 en QG)
 * ------------------------------------------------------------------------- */

static void sdpLoad(unsigned int addr, byte data) {
  fastSetAddress(addr, false);
  dataBusWrite(data);
  PORTB &= ~_BV(PB5);
  __asm__ __volatile__("nop\n\tnop\n\tnop\n\t");
  PORTB |=  _BV(PB5);
}

void disableSDP() {
  if (!confirm(F("SDP: A14 (pin 1) DEBE estar en QG del 595, no en GND. Envia Y."))) return;
  dataBusOutput();
  noInterrupts();
  sdpLoad(0x5555, 0xAA);
  sdpLoad(0x2AAA, 0x55);
  sdpLoad(0x5555, 0x80);
  sdpLoad(0x5555, 0xAA);
  sdpLoad(0x2AAA, 0x55);
  sdpLoad(0x5555, 0x20);
  interrupts();
  delay(20);
  restState();
  Serial.println(F("Secuencia SDP enviada. Prueba 't' y luego 'd'."));
}

/* -------------------------------------------------------------------------
 *  setup / loop
 * ------------------------------------------------------------------------- */

void setup() {
  digitalWrite(WRITE_EN, HIGH);   // alto ANTES de configurarlo como salida
  pinMode(WRITE_EN, OUTPUT);
  pinMode(SHIFT_DATA, OUTPUT);
  pinMode(SHIFT_CLK, OUTPUT);
  pinMode(SHIFT_LATCH, OUTPUT);
  dataBusInput();
  restState();
  Serial.begin(57600);
  help();
}

void loop() {
  if (!Serial.available()) return;
  char c = Serial.read();
  switch (c) {
    case '?': help();               break;
    case 'a': addressLines();       break;
    case 'k': checkA14();           break;
    case 'd': dumpHex(0);           break;
    case 'D': dumpHex(1);           break;
    case 't': testPattern(0);       break;
    case 'T': testPattern(1);       break;
    case 'z': eraseImage(0);        break;
    case 'Z': eraseImage(1);        break;
    case 'w': receiveImage(0);      break;
    case 'W': receiveImage(1);      break;
    case 'r': dumpImageBinary(0);   break;
    case 'R': dumpImageBinary(1);   break;
    case 's': disableSDP();         break;
    default : return;               // ignora saltos de linea y otros
  }
  restState();
}
