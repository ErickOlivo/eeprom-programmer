/*
 * ============================================================================
 *  vga_eeprom_programmer.ino
 *
 *  Arduino Nano + 2 x 74HC595 programmer that writes TWO 100 x 75 images
 *  (64 colors, RRGGBB) into an AT28C256 EEPROM, one in each half ("bank"),
 *  for a Ben Eater-style VGA video card.
 *
 *      Bank 0  (A14 = 0)   addresses 0x0000 - 0x257F   <- image 1
 *      Bank 1  (A14 = 1)   addresses 0x4000 - 0x657F   <- image 2
 *
 *  address = (bank << 14) | (Y << 7) | X      X = 0..99    Y = 0..74
 *
 *  PC-side companion:  tools/image_to_eeprom.py  (option --bank 0|1)
 *  Serial monitor:     57600 baud
 *
 *  See README.md for the full explanation, wiring and troubleshooting.
 *
 * ----------------------------------------------------------------------------
 *  >>> HARDWARE REQUIREMENT (READ BEFORE WRITING BANK 1) <<<
 *
 *  On the PROGRAMMER, A14 (pin 1 of the 28C256) must be driven by QG of the
 *  second 74HC595. If A14 is still tied to GND, writing "to bank 1" actually
 *  OVERWRITES BANK 0 and image 1 is lost. The sketch tries to detect this
 *  before writing (command 'k' and an automatic check), but the detection is
 *  a heuristic: check your wire.
 *
 *  On the VIDEO CARD, to SELECT which image is displayed:
 *      A14 (pin 1) -> GND   : image 1 is shown
 *      A14 (pin 1) -> +5 V  : image 2 is shown
 *  (an SPDT switch or a 3-pin jumper; never leave A14 floating).
 *
 * ----------------------------------------------------------------------------
 *  WIRING
 *
 *    D2 -> SER (pin 14 of the 595s)   D3 -> SRCLK (pin 11)   D4 -> RCLK (pin 12)
 *
 *    595 #1:  QA..QH -> A0..A7    (EEPROM pins 10, 9, 8, 7, 6, 5, 4, 3)
 *    595 #2:  QA -> A8  (pin 25)   QB -> A9  (pin 24)   QC -> A10 (pin 21)
 *             QD -> A11 (pin 23)   QE -> A12 (pin 2)    QF -> A13 (pin 26)
 *             QG -> A14 (pin 1)    QH -> /OE (pin 22)
 *
 *    D5..D12 -> I/O0..I/O7   (EEPROM pins 11, 12, 13, 15, 16, 17, 18, 19)
 *    D13     -> /WE          (pin 27)
 *    /CE (pin 20) -> GND     GND (pin 14) -> GND      VCC (pin 28) -> +5 V
 *
 *    The 595s are daisy-chained: QH' (pin 9) of 595 #1 -> SER of 595 #2.
 *
 * ----------------------------------------------------------------------------
 *  COMMANDS  (lowercase = bank 0, UPPERCASE = bank 1)
 *
 *    ?       help
 *    a       address-line test A0..A14
 *    k       A14 check: compares bank 0 against bank 1
 *    d / D   hex dump of the first 4 rows of bank 0 / 1
 *    t / T   test pattern (T writes it with INVERTED colors so you can tell
 *            at a glance which bank is on screen)
 *    w / W   receive 7500 bytes over serial and write them to bank 0 / 1
 *    r / R   send back the 7500 bytes read from bank 0 / 1 (raw binary)
 *    z / Z   erase the image area of bank 0 / 1 to 0x00
 *    s       disable Software Data Protection (requires A14 on QG)
 *
 *  Why upper/lowercase instead of a "select bank" command: opening the serial
 *  port resets the Nano (DTR line), so a previously selected bank would be
 *  forgotten. Carrying the bank inside the command itself avoids that, and
 *  the Python script needs no prior handshake.
 *
 *  Write safety: idle state has /WE high and /OE low (with /OE low the chip
 *  inhibits write cycles in hardware). Only commands that write raise the
 *  'armed' flag. Always move wires with the USB cable unplugged.
 * ============================================================================
 */

#define SHIFT_DATA    2
#define SHIFT_CLK     3
#define SHIFT_LATCH   4
#define EEPROM_D0     5
#define EEPROM_D7    12
#define WRITE_EN     13

#define IMG_W       100
#define IMG_H        75
#define IMG_BYTES   ((unsigned int)IMG_W * IMG_H)   // 7500
#define BANK_SIZE   0x4000u                          // 16384 bytes (A14)

const byte ACK = 0x06;

bool armed = false;    // true only while a writing command is running

/* -------------------------------------------------------------------------
 *  Data bus through direct port manipulation
 *  D5,D6,D7 = PD5..PD7 -> I/O0..I/O2    D8..D12 = PB0..PB4 -> I/O3..I/O7
 *  D13 (PB5) = /WE (the masks leave it untouched)
 * ------------------------------------------------------------------------- */

static inline void dataBusInput() {
  DDRD  &= ~0xE0;
  DDRB  &= ~0x1F;
  PORTD &= ~0xE0;          // no pull-ups
  PORTB &= ~0x1F;
}

static inline void dataBusOutput() {
  DDRD |= 0xE0;
  DDRB |= 0x1F;
}

static inline void dataBusWrite(byte d) {
  PORTD = (PORTD & ~0xE0) | ((d & 0x07) << 5);
  PORTB = (PORTB & ~0x1F) | ((d >> 3) & 0x1F);
}

/* -------------------------------------------------------------------------
 *  Addressing
 *
 *  The high byte is shifted out first and, through the daisy chain, ends up
 *  in 595 #2. With MSBFIRST bit 7 lands on QH and bit 0 on QA:
 *
 *    bit     7    6    5    4    3    2    1    0
 *    595     QH   QG   QF   QE   QD   QC   QB   QA
 *    signal  /OE  A14  A13  A12  A11  A10  A9   A8
 *
 *  15 address lines + /OE = exactly 16 bits. The address is unsigned so that
 *  0x7FFF is not interpreted as a negative number (int is 16-bit on AVR).
 * ------------------------------------------------------------------------- */

void setAddress(unsigned int address, bool outputEnable) {
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST,
           (byte)((address >> 8) | (outputEnable ? 0x00 : 0x80)));
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, (byte)address);
  digitalWrite(SHIFT_LATCH, LOW);
  digitalWrite(SHIFT_LATCH, HIGH);
  digitalWrite(SHIFT_LATCH, LOW);
}

// Fast version, used only for the SDP sequence, which requires consecutive
// writes within t_BLC (about 150 us). shiftOut + digitalWrite take ~130 us
// per address, which is borderline; this takes ~4 us.
static void fastShiftByte(byte v) {
  for (byte i = 0; i < 8; i++) {
    if (v & 0x80) PORTD |= _BV(PD2); else PORTD &= ~_BV(PD2);
    PORTD |=  _BV(PD3);
    PORTD &= ~_BV(PD3);
    v <<= 1;
  }
}

static void fastSetAddress(unsigned int address, bool outputEnable) {
  fastShiftByte((byte)((address >> 8) | (outputEnable ? 0x00 : 0x80)));
  fastShiftByte((byte)address);
  PORTD |=  _BV(PD4);
  PORTD &= ~_BV(PD4);
}

// bank = 0 or 1. A14 is bit 14 of the address (0x4000).
static inline unsigned int pixelAddr(byte x, byte y, byte bank) {
  return ((unsigned int)bank << 14) | ((unsigned int)y << 7) | x;
}

/* -------------------------------------------------------------------------
 *  Read, write and idle state
 * ------------------------------------------------------------------------- */

void restState() {
  digitalWrite(WRITE_EN, HIGH);
  dataBusInput();
  setAddress(0, true);          // /OE low: writes inhibited in hardware
}

byte readEEPROM(unsigned int address) {
  dataBusInput();
  setAddress(address, true);
  delayMicroseconds(2);         // longer than the chip's t_ACC
  byte data = 0;
  for (int pin = EEPROM_D7; pin >= EEPROM_D0; pin--)
    data = (data << 1) | digitalRead(pin);
  return data;
}

void writeEEPROM(unsigned int address, byte data) {
  if (!armed) return;           // safety: nothing is written unless armed
  setAddress(address, false);   // /OE high: write enabled
  dataBusOutput();
  dataBusWrite(data);
  digitalWrite(WRITE_EN, LOW);
  delayMicroseconds(1);         // ~1 us pulse (chip minimum: 100 ns)
  digitalWrite(WRITE_EN, HIGH);
  dataBusInput();
  delay(10);                    // internal write cycle (t_WC max)
  // Possible optimization: instead of a fixed delay(10), use DATA polling
  // (read I/O7 until it matches the written bit 7). That brings the typical
  // time down to 3-5 ms but adds a failure mode (infinite loop if the chip
  // does not respond). For breadboard debugging the fixed delay is safer.
}

/* -------------------------------------------------------------------------
 *  Console helpers
 * ------------------------------------------------------------------------- */

void printHex(byte b) {
  if (b < 16) Serial.print('0');
  Serial.print(b, HEX);
}

bool confirm(const __FlashStringHelper *msg) {
  Serial.println(msg);
  delay(100);
  while (Serial.available()) Serial.read();   // discard the line ending
  unsigned long t0 = millis();
  while (!Serial.available()) {
    if (millis() - t0 > 15000UL) {
      Serial.println(F("Cancelled (no answer within 15 s)."));
      return false;
    }
  }
  if (Serial.read() != 'Y') {
    Serial.println(F("Cancelled."));
    return false;
  }
  return true;
}

void help() {
  Serial.println();
  Serial.println(F("VGA AT28C256 programmer - 2 banks (100x75, 64 colors RRGGBB)"));
  Serial.println(F("  lowercase = bank 0 (A14=0)   UPPERCASE = bank 1 (A14=1)"));
  Serial.println(F("  ?    help"));
  Serial.println(F("  a    address-line test A0..A14"));
  Serial.println(F("  k    A14 check (bank 0 vs bank 1)"));
  Serial.println(F("  d/D  hex dump of 4 rows"));
  Serial.println(F("  t/T  test pattern (T = inverted colors)"));
  Serial.println(F("  w/W  receive and write an image over serial (7500 bytes)"));
  Serial.println(F("  r/R  send back the 7500 bytes read (binary)"));
  Serial.println(F("  z/Z  erase the image area to 0x00"));
  Serial.println(F("  s    disable SDP [requires A14 on QG]"));
}

/* -------------------------------------------------------------------------
 *  A14 diagnostics
 *
 *  Compares 64 bytes of bank 0 with 64 bytes of bank 1. If A14 does NOT
 *  reach the chip (pin 1 grounded or loose), both halves are a mirror of
 *  each other and the 64 bytes come out identical.
 *
 *  Limitation: if both banks genuinely hold the same data (e.g. both blank,
 *  all 0xFF), this will also report "mirror". It is an alarm, not a proof.
 *  The definitive test: write pattern T to bank 1 and check with 'd' that
 *  bank 0 is unchanged.
 * ------------------------------------------------------------------------- */

// returns true if A14 seems to work (the banks differ)
bool a14Differs() {
  for (byte i = 0; i < 64; i++) {
    if (readEEPROM(i) != readEEPROM(BANK_SIZE + i)) return true;
  }
  return false;
}

void checkA14() {
  Serial.println(F("Bank 0 (0x0000):          Bank 1 (0x4000):"));
  for (byte i = 0; i < 8; i++) {
    printHex(readEEPROM(i));
    Serial.print(F(" "));
  }
  Serial.print(F("  |  "));
  for (byte i = 0; i < 8; i++) {
    printHex(readEEPROM(BANK_SIZE + i));
    Serial.print(F(" "));
  }
  Serial.println();
  if (a14Differs()) {
    Serial.println(F("OK: the banks differ -> A14 reaches the chip."));
  } else {
    Serial.println(F("WARNING: the banks are IDENTICAL (mirror)."));
    Serial.println(F("  Causes: A14 (pin 1) grounded/loose, or both banks blank (FF)."));
    Serial.println(F("  Measure pin 1 with a multimeter: it must switch 0 V <-> 5 V"));
    Serial.println(F("  depending on the address (QG of 595 #2)."));
  }
}

// Before writing bank 1: if it looks like a mirror, warn about the risk.
bool bank1Safe() {
  if (a14Differs()) return true;
  return confirm(F("WARNING: bank 1 looks like a mirror of bank 0. If A14 is on GND, "
                   "WRITING HERE ERASES IMAGE 1. Sure? Send Y."));
}

void addressLines() {
  Serial.print(F("0x0000 = "));
  printHex(readEEPROM(0));
  Serial.println();
  for (byte k = 0; k < 15; k++) {            // A0..A14
    unsigned int a = (unsigned int)1 << k;
    Serial.print(F("A"));
    Serial.print(k);
    Serial.print(F(" (0x"));
    Serial.print(a, HEX);
    Serial.print(F(") = "));
    printHex(readEEPROM(a));
    Serial.println();
  }
}

void dumpHex(byte bank) {
  Serial.print(F("Bank "));
  Serial.println(bank);
  for (byte y = 0; y < 4; y++) {
    for (byte base = 0; base < IMG_W; base += 16) {
      char buf[8];
      sprintf(buf, "%04X:", pixelAddr(base, y, bank));
      Serial.print(buf);
      for (byte off = 0; off < 16 && (byte)(base + off) < IMG_W; off++) {
        Serial.print(' ');
        printHex(readEEPROM(pixelAddr(base + off, y, bank)));
      }
      Serial.println();
    }
  }
}

/* -------------------------------------------------------------------------
 *  Test pattern: 8x8 grid with all 64 colors and a 1-pixel white border.
 *
 *  The grid shows every color at once, so a wrong DAC resistor shows up as a
 *  column or row of repeated colors. The border checks that the visible
 *  window matches the image area (bad blanking cuts the border or adds
 *  stripes outside it).
 *
 *  In bank 1 the 6 color bits are inverted (c ^ 0x3F): the border becomes
 *  BLACK and the grid shows complementary colors, so switching A14 on the
 *  video card produces an unmistakable change.
 * ------------------------------------------------------------------------- */

void testPattern(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  if (!confirm(F("Test pattern: OVERWRITES the selected bank. Send Y."))) return;
  armed = true;
  Serial.print(F("Writing pattern to bank "));
  Serial.print(bank);
  Serial.println(F(" (approx. 75 s)..."));
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) {
      byte c;
      if (x == 0 || x == IMG_W - 1 || y == 0 || y == IMG_H - 1) {
        c = 0x3F;                                            // full white
      } else {
        byte col = (byte)(((unsigned int)x * 8) / IMG_W);    // 0..7
        byte row = (byte)(((unsigned int)y * 8) / IMG_H);    // 0..7
        c = (byte)(row * 8 + col);                           // 0..63
      }
      if (bank == 1) c ^= 0x3F;
      writeEEPROM(pixelAddr(x, y, bank), c);
    }
    Serial.print('.');
  }
  armed = false;
  restState();
  Serial.println();
  Serial.println(F("Pattern written."));
}

void eraseImage(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  if (!confirm(F("Erase the image area of the selected bank to 0x00. Send Y."))) return;
  armed = true;
  Serial.print(F("Erasing bank "));
  Serial.print(bank);
  Serial.println(F(" (approx. 75 s)..."));
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) writeEEPROM(pixelAddr(x, y, bank), 0x00);
    Serial.print('.');
  }
  armed = false;
  restState();
  Serial.println();
  Serial.println(F("Done."));
}

/* -------------------------------------------------------------------------
 *  Image over serial
 *
 *  Protocol (tools/image_to_eeprom.py implements the PC side):
 *    PC -> 'w' (bank 0) or 'W' (bank 1)
 *    AR -> "READY\r\n"
 *    repeat 7500 times:  PC -> 1 byte | AR writes it and answers 0x06 (ACK)
 *    AR -> "DONE 7500\r\n"
 *
 *  The per-byte ACK prevents overflowing the Nano's 64-byte receive buffer:
 *  each write takes 10 ms, so the PC can never go faster than the chip.
 *
 *  Note: the bank-1 mirror warning uses confirm(), which waits for a 'Y'
 *  from a human. A script cannot answer it, so if the check fires the script
 *  receives "Cancelled" instead of READY and stops. This is intended: it is
 *  better than silently erasing image 1 because of a misplaced wire.
 * ------------------------------------------------------------------------- */

void receiveImage(byte bank) {
  if (bank == 1 && !bank1Safe()) return;
  delay(50);
  while (Serial.available()) Serial.read();   // discard the line ending
  Serial.println(F("READY"));
  armed = true;
  unsigned int count = 0;
  for (byte y = 0; y < IMG_H; y++) {
    for (byte x = 0; x < IMG_W; x++) {
      unsigned long t0 = millis();
      while (!Serial.available()) {
        if (millis() - t0 > 10000UL) {
          armed = false;
          restState();
          Serial.println();
          Serial.print(F("TIMEOUT at byte "));
          Serial.println(count);
          return;
        }
      }
      writeEEPROM(pixelAddr(x, y, bank), (byte)Serial.read());
      Serial.write(ACK);
      count++;
    }
  }
  armed = false;
  restState();
  Serial.print(F("DONE "));
  Serial.println(count);
}

void dumpImageBinary(byte bank) {
  Serial.println(F("DATA"));
  delay(10);
  for (byte y = 0; y < IMG_H; y++)
    for (byte x = 0; x < IMG_W; x++)
      Serial.write(readEEPROM(pixelAddr(x, y, bank)));
  Serial.flush();
}

/* -------------------------------------------------------------------------
 *  Disabling Software Data Protection (SDP)
 *
 *  Symptom of a locked chip: the programmer reports no error, but reading
 *  back gives all 0xFF, exactly like a loose wire. If 't' writes and 'd'
 *  still shows FF, try this BEFORE checking the wiring.
 *
 *  The sequence writes to 0x5555 and 0x2AAA, which use A13 and A14: with A14
 *  on GND it cannot be executed. Check the sequence against the Microchip
 *  AT28C256 datasheet before relying on it.
 * ------------------------------------------------------------------------- */

static void sdpLoad(unsigned int addr, byte data) {
  fastSetAddress(addr, false);
  dataBusWrite(data);
  PORTB &= ~_BV(PB5);                               // /WE low
  __asm__ __volatile__("nop\n\tnop\n\tnop\n\t");    // ~190 ns (min 100 ns)
  PORTB |=  _BV(PB5);                               // /WE high
}

void disableSDP() {
  if (!confirm(F("SDP: A14 (pin 1) MUST be on QG of the 595, not on GND. Send Y."))) return;
  dataBusOutput();
  noInterrupts();
  sdpLoad(0x5555, 0xAA);
  sdpLoad(0x2AAA, 0x55);
  sdpLoad(0x5555, 0x80);
  sdpLoad(0x5555, 0xAA);
  sdpLoad(0x2AAA, 0x55);
  sdpLoad(0x5555, 0x20);
  interrupts();
  delay(20);
  restState();
  Serial.println(F("SDP sequence sent. Try 't' and then 'd'."));
}

/* -------------------------------------------------------------------------
 *  setup / loop
 * ------------------------------------------------------------------------- */

void setup() {
  digitalWrite(WRITE_EN, HIGH);   // drive high BEFORE making it an output
  pinMode(WRITE_EN, OUTPUT);
  pinMode(SHIFT_DATA, OUTPUT);
  pinMode(SHIFT_CLK, OUTPUT);
  pinMode(SHIFT_LATCH, OUTPUT);
  dataBusInput();
  restState();
  Serial.begin(57600);
  help();
}

void loop() {
  if (!Serial.available()) return;
  char c = Serial.read();
  switch (c) {
    case '?': help();               break;
    case 'a': addressLines();       break;
    case 'k': checkA14();           break;
    case 'd': dumpHex(0);           break;
    case 'D': dumpHex(1);           break;
    case 't': testPattern(0);       break;
    case 'T': testPattern(1);       break;
    case 'z': eraseImage(0);        break;
    case 'Z': eraseImage(1);        break;
    case 'w': receiveImage(0);      break;
    case 'W': receiveImage(1);      break;
    case 'r': dumpImageBinary(0);   break;
    case 'R': dumpImageBinary(1);   break;
    case 's': disableSDP();         break;
    default : return;               // ignore line endings and other chars
  }
  restState();
}
